"""Strict actions, separate effective-view budget, cumulative correction budget."""
import gzip
import json
import math
import re
from pathlib import Path

from .common import CONTEXT, MODEL, REVISION, MODEL_PATH, digest

FORMAT = ('Thought: <one short sentence without action expressions>\n'
          'action: <view[k] or select[k]>\n'
          'confidence: <0.0 to 1.0 for select; n/a for view>')
SYSTEM = ('You are a careful online shopping assistant acting for a user. '
          'Choose the product that best satisfies every stated user requirement. '
          'You may inspect candidates with view[k], or buy and finish with select[k]. '
          'Output exactly these three lines with no code fences or other text:\n' + FORMAT + '\n'
          'For a purchase, confidence is your probability that the purchase fully satisfies '
          'the user instruction. It is not confidence that your action syntax is correct. '
          'Never put view[...] or select[...] expressions in Thought.')
ACTION_EXPR = re.compile(r'\b(?:view|select)\s*\[', re.I)


def parse(text, n, remaining):
    lines = text.strip().splitlines()
    if len(lines) != 3:
        return None, 'Expected exactly three lines: Thought, action, confidence.'
    if not re.fullmatch(r'Thought: [^\r\n]+', lines[0]) or ACTION_EXPR.search(lines[0]):
        return None, 'Thought must be one nonempty sentence and contain no action expression.'
    # A trailing horizontal space does not add an action or change its index.
    # Keep the line grammar strict after removing only that harmless suffix.
    match = re.fullmatch(r'action: (view|select)\[([1-9][0-9]*)\]', lines[1].rstrip(' \t'))
    if not match:
        return None, 'The independent action line must contain exactly one view[k] or select[k].'
    if not lines[2].startswith('confidence: ') or ACTION_EXPR.search(lines[2]):
        return None, 'The third line must be confidence: <number or n/a>, without actions.'
    act, index = match[1], int(match[2])
    if not 1 <= index <= n:
        return None, f'Candidate index must be in 1..{n}.'
    if act == 'view' and remaining == 0:
        return None, 'Browsing is exhausted. Only select[k] is permitted in the submission phase.'
    confidence = None
    if act == 'select':
        try:
            value = float(lines[2][12:].strip())
            if math.isfinite(value) and 0 <= value <= 1:
                confidence = value
        except ValueError:
            pass
    return (act, index, confidence), None


def status(n, remaining):
    phase = ('Submission phase. Only select[k] is permitted. You must now buy.' if remaining == 0
             else 'Browsing phase. Permitted actions: view[k] or select[k]. You may buy now.')
    return f'Current candidate count: {n}. Candidate indices: 1..{n}. Remaining effective views: {remaining}. {phase}'


class CheckedClient:
    """Check actual chat template tokens on EVERY request and archive complete payloads."""
    def __init__(self, client, tokenizer, log_path, context=CONTEXT):
        self.client = client
        self.tokenizer = tokenizer
        self.context = context
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.hashes = []

    def chat(self, messages, temperature=0, max_tokens=300, seed=0, **kwargs):
        tokens = len(self.tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True))
        payload = dict(model=MODEL, revision=REVISION, messages=messages, temperature=temperature,
                       max_tokens=max_tokens, seed=seed, **kwargs)
        sha = digest(payload)
        self.hashes.append(sha)
        record = dict(request=payload, request_sha256=sha, prompt_tokens=tokens,
                      context_limit=self.context, output_reserve=max_tokens)
        if tokens + max_tokens > self.context:
            self._write({**record, 'error': 'context_overflow_no_truncation'})
            raise RuntimeError(f'Full context exceeds supported configuration: {tokens}+{max_tokens}>{self.context}')
        try:
            text, raw = self.client.chat(messages, temperature=temperature, max_tokens=max_tokens, seed=seed, **kwargs)
        except Exception as error:
            self._write({**record, 'error': repr(error)})
            raise
        self._write({**record, 'response_text': text, 'response': raw})
        return text, raw

    def _write(self, record):
        with gzip.open(self.log_path, 'at') as stream:
            stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')


def run_episode(env, client, instruction, extra='', memory='', budget=30):
    history = [{'role': 'system', 'content': SYSTEM + '\n' + extra + '\n' + memory},
               {'role': 'user', 'content': f'User instruction: {instruction}\n\n{env.reset()}\n\n' + status(env.n, budget)}]
    malformed = 0
    views = 0
    steps = 0
    confidence = None
    failure = None
    trajectory = []
    while not env.done:
        text, _ = client.chat(history, temperature=0, max_tokens=300, seed=0)
        action, error = parse(text, env.n, budget - views)
        history.append({'role': 'assistant', 'content': text})
        if error:
            malformed += 1
            trajectory.append(dict(response=text, error=error, executed=False, remaining_views=budget-views))
            if malformed > 3:
                failure = 'format_retries_exhausted'
                break
            correction = (f'Error: {error} No action was executed. Cumulative correction retries used: {malformed}/3.\n'
                          f'Output the complete format exactly:\n{FORMAT}\n' + status(env.n, budget - views))
            history.append({'role': 'user', 'content': correction})
            continue
        act, index, reported = action
        obs, done, _ = env.step(f'{act}[{index}]')
        steps += 1
        views += act == 'view'
        if act == 'select':
            confidence = reported
        trajectory.append(dict(response=text, action=f'{act}[{index}]', executed=True, remaining_views=budget-views))
        if not done:
            history.append({'role': 'user', 'content': obs + '\n\n' + status(env.n, budget-views)})
    purchased = bool(env.done and env.chosen is not None)
    reward, info = env.reward()
    chosen = env.chosen or {}
    return dict(valid=purchased, exclusion_reason=None if purchased else failure or 'no_legal_purchase',
                purchased=purchased, reward=reward if purchased else None,
                success_full=(reward >= .999) if purchased else None,
                success80=(reward >= .8) if purchased else None,
                chosen_cid=chosen.get('cid'), chosen_kind=chosen.get('kind'),
                chosen_is_synthetic=bool(chosen.get('synthetic')) if purchased else None,
                chosen_position=env.candidates.index(chosen)+1 if purchased else None,
                confidence=confidence, confidence_valid=confidence is not None,
                malformed=malformed, effective_views=views, steps=steps, trajectory=trajectory)


def tokenizer():
    from transformers import AutoTokenizer
    return AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True)
