import unittest
import tempfile
import gzip
import json
from pathlib import Path
from .executor import parse, run_episode, CheckedClient


def reply(action, confidence='0.8'):
    return f'Thought: I compared the requirements.\naction: {action}\nconfidence: {confidence}'


class Env:
    n = 2
    candidates = [dict(cid='a', kind='gold'), dict(cid='b', kind='synthetic:clone', synthetic=True)]
    def reset(self):
        self.done = False
        self.chosen = None
        return 'Candidates'
    def step(self, action):
        if action.startswith('select'):
            self.done = True
            self.chosen = self.candidates[int(action[7:-1])-1]
        return 'Page', self.done, {}
    def reward(self):
        return 1., {}


class Client:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.messages = []
    def chat(self, messages, **kwargs):
        self.messages.append(list(messages))
        return next(self.responses), {}


class Tests(unittest.TestCase):
    def test_parser(self):
        for n in (2, 10):
            self.assertIsNotNone(parse(reply(f'select[{n}]'), n, 0)[0])
        bad = [reply('select[3]'), reply('select[0]'), reply('view[1] select[2]'),
               reply('select[1]').replace('I compared the requirements.', 'I considered view[1].'),
               '```\n' + reply('select[1]') + '\n```', reply('select[1]')+'\nextra',
               reply('select[1]')+'\naction: select[2]']
        for text in bad:
            self.assertIsNone(parse(text, 2, 6)[0], text)
        self.assertIsNone(parse(reply('view[1]'), 2, 0)[0])
        self.assertIsNone(parse(reply('select[1]', 'nan'), 2, 0)[0][2])
        self.assertIsNone(parse(reply('select[1]', '1.5'), 2, 0)[0][2])

    def test_last_view_gets_select(self):
        for budget in (6, 30):
            client = Client([reply('view[1]', 'n/a')]*budget + [reply('select[2]')])
            result = run_episode(Env(), client, 'goal', budget=budget)
            self.assertTrue(result['valid'])
            self.assertEqual(result['effective_views'], budget)
            self.assertIn('Submission phase', client.messages[-1][-1]['content'])

    def test_cumulative_retries(self):
        client = Client(['bad', reply('view[1]'), 'bad', reply('view[2]'), 'bad', reply('select[1]')])
        result = run_episode(Env(), client, 'goal', budget=6)
        self.assertTrue(result['valid'])
        self.assertEqual(result['malformed'], 3)
        self.assertEqual(result['effective_views'], 2)
        result = run_episode(Env(), Client(['bad', reply('view[1]'), 'bad', 'bad', 'bad']), 'goal', budget=6)
        self.assertFalse(result['valid'])
        self.assertIsNone(result['reward'])
        self.assertEqual(result['effective_views'], 1)

    def test_submission_retry(self):
        result = run_episode(Env(), Client([reply('view[1]')]*6+[reply('view[2]'), reply('select[1]', 'unknown')]), 'goal', budget=6)
        self.assertTrue(result['valid'])
        self.assertEqual(result['malformed'], 1)
        self.assertIsNone(result['confidence'])

    def test_no_context_truncation(self):
        class Tokenizer:
            def apply_chat_template(self,messages,**kwargs):
                return list(range(30))
        base=Client([])
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'requests.jsonl.gz'
            checked=CheckedClient(base,Tokenizer(),path,context=32)
            messages=[dict(role='user',content='Complete memory stays intact')]
            with self.assertRaises(RuntimeError):
                checked.chat(messages,max_tokens=3)
            self.assertEqual(base.messages,[])
            with gzip.open(path,'rt') as stream:
                record=json.loads(stream.readline())
            self.assertEqual(record['request']['messages'],messages)
            self.assertEqual(record['prompt_tokens'],30)

    def test_full_memory(self):
        from .washout import full_memory
        class Memory:
            entries=[dict(type='observation',text=f'note {i}') for i in range(80)]
            entries+=[dict(type='lesson',text=f'lesson {i}') for i in range(16)]
        text=full_memory(Memory())
        self.assertEqual(text.count('- [observation]'),80)
        self.assertEqual(text.count('- [lesson]'),16)
        self.assertIn('note 0\n',text)
        self.assertIn('lesson 15',text)


if __name__ == '__main__':
    unittest.main()
